scoreboard objectives add crispy.trail dummy
scoreboard objectives add crispy.walk minecraft.custom:minecraft.walk_one_cm
scoreboard objectives add crispy.sprint minecraft.custom:minecraft.sprint_one_cm
schedule function crispy_cos:tick 2t replace
