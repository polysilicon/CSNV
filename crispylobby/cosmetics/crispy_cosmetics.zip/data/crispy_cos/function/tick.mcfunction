execute as @a run scoreboard players operation @s crispy.walk += @s crispy.sprint
execute as @a[scores={crispy.trail=1..,crispy.walk=1..},gamemode=!spectator] at @s unless predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{effects:{"minecraft:invisibility":{}}}} run function crispy_cos:trail
scoreboard players reset @a crispy.walk
scoreboard players reset @a crispy.sprint
schedule function crispy_cos:tick 2t replace
