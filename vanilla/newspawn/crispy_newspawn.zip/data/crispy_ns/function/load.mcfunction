scoreboard objectives add ns.ok dummy
schedule function crispy_ns:tick 10t replace
