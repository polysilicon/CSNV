tag @s add ns.seen
effect give @s minecraft:slow_falling 10 0 true
effect give @s minecraft:resistance 10 4 true
execute store success score @s ns.ok run spreadplayers 16 -48 0 1500 under 200 false @s
execute if score @s ns.ok matches 1 at @s run spawnpoint @s ~ ~ ~
execute if score @s ns.ok matches 1 run tellraw @s [{"text":"Welcome to CrispyAnarchy Vanilla! ","color":"green","bold":true},{"text":"You've been dropped somewhere safe in the wild - this is your respawn point until you sleep in a bed.","color":"gray","bold":false}]
