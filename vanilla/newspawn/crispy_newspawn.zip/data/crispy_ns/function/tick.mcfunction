execute if entity @a[tag=!ns.seen] run function crispy_ns:check
schedule function crispy_ns:tick 10t replace
